<?php
include "conn.php";

$foto = $_FILES["img"];
$nome=$_POST['nome'];
$acro=$_POST['acro'];
$local=$_POST['local'];
$qts=$_POST['qts'];
$cts=$_POST['cts'];
$dpi=$_POST['dpi'];
$info=$_POST['info'];
$fun=$_GET['fun'];
$n=$_GET['idi'];
if($fun==1){
mysql_query("insert into institutos(nome,localizacao,qtd_salas,criterio_acesso,doc_inscricao,info,acronimo) values('$nome','$local','$qts','$cts','$dpi','$info','$acro')");
$qr=mysql_query("SELECT id_institutos FROM institutos WHERE nome='$nome' and localizacao='$local' and qtd_salas='$qts' and criterio_acesso='$cts' and doc_inscricao='$dpi' and info='$info' and acronimo='$acro' ");
preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $foto["name"], $ext);
$nome_imagem = md5(uniqid(time())) . "." . $ext[1];
$caminho_imagem = "../fotos/institutos/" . $nome_imagem;
move_uploaded_file($foto["tmp_name"], $caminho_imagem);

$re=mysql_fetch_array($qr);
$f_cod=$re['id_institutos'];
mysql_query("insert into fotos(id_institutos,nome) values('$f_cod','$nome_imagem') ");

			
}
if($fun==2){
mysql_query("delete from institutos where id_institutos=$n");
}
header('Location:index.php?page=php/cadastroins');
?>