<?php
$val=$_GET['val'];
include "conn.php";
$new=mysql_query("select *from cursos where id_cursos='$val'");
$result=mysql_fetch_array($new);
$codes=$result['id_cursos'];
$nome=$result['nome'];
$info=$result['info'];
$qery=mysql_query("SELECT i.* FROM inst_curso AS it JOIN institutos AS i ON i.id_institutos = it.id_institutos JOIN cursos AS c ON it.id_cursos = c.id_cursos WHERE c.id_cursos = '$codes'");
$d_query=mysql_query("select *from disciplinas where id_cursos='$codes'");
?>

<head>
	<title><?php echo "$nome"; ?></title>
</head>

<div id="slider">

<img src="img/fundos/slider.jpg" />

</div>

	<h4>Nome:</h4><h4><?php echo "$nome"; ?></h4><br>
	<h4>Disciplinas que este curso contem:</h4>
	<?php 
		while ($nova=mysql_fetch_array($d_query)) {
			$d_nome=$nova['nome'];
		?>
	<h4><?php echo "$d_nome"; ?></h4><br>
	<?php } ?>
	<h4>Institutos que contem este cursos:</h4>
	<?php 
		while ($nov=mysql_fetch_array($qery)) {
			$ncod=$nov['id_institutos'];
			$d_ome=$nov['nome'];
		?>
	<a href="php/localinstitutos.php?new=<?php echo "$ncod"; ?>"><h4><?php echo "$d_ome"; ?></h4></a><br>
	<?php } ?>
	<h4>Nome:</h4><h4><?php echo "$info"; ?></h4><br>
	<a href="index.php?page=cursos
	"><button>Voltar</button></a>
	