<?php
include "conn.php";
$nome=$_POST['nome'];
$info=$_POST['infor'];
$fun=$_GET['fun'];
$n=$_GET['idi'];

if($fun==1){
mysql_query("insert into cursos(nome,info) values('$nome','$info')");

}
if($fun==2){
mysql_query("delete from cursos where id_cursos=$n");
}
	header("Location:cursos.php");
?>