<?php
include "conn.php";
$id=$_GET['new'];
$sel=mysql_query("select *from institutos where id_institutos=$id");
$select=mysql_fetch_array($sel);
$codes=$select['id_institutos'];
$nome=$select['nome'];
$local=$select['localizacao'];
$qtd=$select['qtd_salas'];
$cta=$select['criterio_acesso'];
$doc=$select['doc_inscricao'];
$info=$select['info'];
$acro=$select['acronimo'];


?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php echo "$nome"; ?></title>
</head>
<body>
<h4>Acronimo:</h4><h4><?php echo "$acro"; ?></h4><br/>
<h4>nome:</h4><h4><?php echo "$nome"; ?></h4><br/>
<h4>Neste Instituto tem os seguintes cursos:</h4>
<?php 
	$qery=mysql_query("SELECT c.* FROM inst_curso AS it JOIN institutos AS i ON i.id_institutos = it.id_institutos JOIN cursos AS c ON it.id_cursos = c.id_cursos WHERE i.id_institutos = '$codes'");	
	while ($query=mysql_fetch_array($qery)) {
		    $ncod=$query['id_cursos'];
			$c_nome=$query['nome'];
 ?>
 <a href="localcursos.php?val=<?php echo "$ncod"; ?>"><h4><?php echo "$c_nome" ?></h4></a>
 <?php } ?>
<h4>Localização:</h4><h4><?php echo "$local"; ?></h4><br/>
<h4>Quantidades de Salas:</h4><h4><?php echo "$qtd"; ?></h4><br/>
<h4>Critério Para entrar:</h4><h4><?php echo "$cta"; ?></h4><br/>
<h4>Documentos Para inscrição:</h4><h4><?php echo "$doc"; ?></h4><br/>
<h4>Informação:</h4><h4><?php echo "$info"; ?></h4><br/>
<a href="index.php?page=institutos"><button>Voltar</button></a>
</body>

</html>