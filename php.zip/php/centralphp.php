<?php
include "conn.php";
?>

<div id="slider">

<img src="img/fundos/curso-ecommerce.jpg" />

</div>

	<!-- <div>
		<nav class="menu">
			<ul>
				<li><a href="?page=php/disciplina">Gestão de Disciplina</a></li>
				<li><a href="?page=php/cursos" onclik="<?php $num=1 ?>; result(1);">Gestão de Cursos</a></li>
				<li><a href="?page=php/cadastroins">Gestão de Institutos</a></li>
				<li><a href="?page=php/inst_curso">Gestão de Opiniões Instituições com cursos</a></li>
				<li><a href="?page=php/admin">Gestão de Users</a></li>
			</ul>
		</nav>
	</div>



 -->
	
     
   
<!-- <div id="tabs-container">
    <ul class="tabs-menu">
        <li class="current"><a href="#tab1">Fala</a></li>
    <li><a href="#tab2">Gestão de Disciplinas</a></li>
    <li><a href="#tab3">Gestão de Cursos</a></li>
    <li><a href="#tab4">Gestão de Institutos</a></li>
    <li><a href="#tab5">Gestão de Opiniões (Instituições com cursos)</a></li>
    <li><a href="#tab6">Gestão de Usuarios</a></li>
    </ul>

      
        </div> -->
  
<div class="conteudo_admin">

		
<a href="php/cursos.php">	<figure class="admin_box">

<img  src="img/fundos/Structure.jpg" />
  
  <figcaption>
    
    <h3>Gestão de Cursos</h3>
    <p>Aceder <i class="icon-globe icon-white"></i></p>

  </figcaption>

  <label class="lb_curso" ><i class="icon-cog"></i>Cadastrar Cursos</label>
</figure></a>



<a href="php/cadastroins.php"><figure class="admin_box">

<img src="img/fundos/Structure.jpg" />
  
  <figcaption>
    
    <h3>Gestão de Institutos</h3>
    <p>Aceder <i class="icon-globe icon-white"></i></p>

  </figcaption>

   <label class="lb_curso" ><i class="icon-cog"></i>Cadastrar Institutos</label>
</figure></a>


<a href="#"><figure class="admin_box">

<img src="img/fundos/Structure.jpg" />
  
  <figcaption>
    
    <h3>Gestão de Opiniões & Gestão do Fale</h3>
    <p>Aceder <i class="icon-globe icon-white"></i></p>

  </figcaption>

<label class="lb_curso" >Gestão de Opinioes & Gestão do Fale<i class="icon-bullhorn"></i></label>

</figure></a>


<a href="php/disciplina.php"><figure class="admin_box">

<img src="img/fundos/Structure.jpg" />
  
  <figcaption>
    
    <h3>Gestão de Disciplinas</h3>
    <p>Aceder <i class="icon-globe icon-white"></i></p>

  </figcaption>

  <label class="lb_curso" ><i class="icon-book"></i>Cadastrar Disciplinas</label>
</figure></a>

<a href="php/admin.php"><figure class="admin_box">

<img src="img/fundos/Structure.jpg" />
  
  <figcaption>
    
    <h3>Gestão de Usuarios</h3>
    <p>Aceder <i class="icon-globe icon-white"></i></p>

  </figcaption>

  <label class="lb_curso" >Cadastrar de Usuarios <i class="icon-user"></i></label>
</figure></a>

  


</div>