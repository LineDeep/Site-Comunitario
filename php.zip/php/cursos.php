<?php include "conn.php"; ?>
<!doctype html>
<head>
	<style type="text/css">
	#ner td{
		padding: 5px;
	}
	</style>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cadrastro no Banco</title>
</head>

<body>
	<form method="POST" action="cadastCurso.php?fun=1" name="form_inst">
	<table >
		<tr>
			<td><label>Nome:</label></td><td><input type="text" name="nome"></td>
		</tr>
		<tr>
			<td><label>Informação:</label></td><td><textarea name="infor"></textarea> </td>
		</tr>
		<tr><td><input type="submit" value="Cadastrar"></td></tr>
	</table>
	<table id="ner" >
		<tr><a href="index.php?page=php/centralphp"><input type="button" value="Voltar"></a></tr>
		<tr>
			<td>Codigo</td>
			<td>Nome</td>
			<td>Informação</td>
		</tr>
		<?php
			$select=mysql_query("select *from cursos");
			while($rec_select=mysql_fetch_array($select)){
			$cod=$rec_select['id_cursos'];
			$nome=$rec_select['nome'];
			$infor=$rec_select['info'];
		?>
		<tr>
			<td><?php echo "$cod" ?></td>
			<td><?php echo "$nome" ?></td>
			<td><?php echo "$infor" ?></td>
			<td><a href="cadastCurso.php?fun=2&idi=<?php echo "$cod" ?>">Eliminar</a></td>
		</tr>
<?php } ?>
	</table>
</body>
</html>			