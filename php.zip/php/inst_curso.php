<?php include "conn.php"; ?>
<!doctype html>
<head>
	<style type="text/css">
	#ner td{
		padding: 5px;
	}
	</style>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cadrastro no Banco</title>
</head>

<body>
	<h1>Conexão entre Institutos e Cursos</h1>
	<form method="POST" action="http://localhost/Scom/php/cadasInst_curso.php?fun=1" name="form_inst">
	<table >
		<tr>
			<td><label>Instituto:</label></td><td>
				<select name="instos">
					<option></option>
					<?php
						$query_institutos=mysql_query("SELECT * FROM `institutos` WHERE 1");
							while ($result_institutos=mysql_fetch_array($query_institutos)) {
								$value=$result_institutos['nome']; 
						
						 
					?>
					<option><?php echo "$value"; ?></option>
					<?php } ?>
				</select>
			</td>
			</tr>
			<tr>
			<td><label>Curso:</label></td>
			<td>
				<select name="cursos">
					<option></option>
					<?php
						$query_cursos=mysql_query("SELECT * FROM `cursos` WHERE 1");
							while ($result_cursos=mysql_fetch_array($query_cursos)) {
								$values=$result_cursos['nome']; 
					?>
					<option><?php echo "$values"; ?></option>
					<?php } ?>
				</selecct>
			</td>
			<tr><td><input type="submit" value="Cadastrar"></td></tr>
			</tr>
		</table>

			<table id="ner">
				<tr><a href="index.php?page=php/centralphp"><input type="button" value="Voltar"></a></tr>
				<tr>
					<td>Codigo</td>
					<td>Institutos</td>
					<td>Cursos</td>
				</tr>
				<?php
					$query_inscur=mysql_query("SELECT * FROM `inst_curso` WHERE 1");
						while($result_inscur=mysql_fetch_array($query_inscur)){
						$ving=$result_inscur['id_inst_curso'];
						$curs=$result_inscur['id_cursos'];
						$inst=$result_inscur['id_institutos'];
						$query_instittos=mysql_query("SELECT * FROM `institutos` WHERE id_institutos=$inst");
						$result_instittos=mysql_fetch_array($query_instittos);
						$valus=$result_instittos['nome'];
						$query_curos=mysql_query("SELECT * FROM `cursos` WHERE id_cursos=$curs");
						$result_curos=mysql_fetch_array($query_curos);
						$vals=$result_curos['nome'];
					  
				?>
				<tr>
					<td><?php echo "$ving"; ?></td>
					<td><?php echo "$valus"; ?></td>
					<td><?php echo "$vals"; ?></td>
					<td><a href="http://localhost/Scom/php/cadasInst_curso.php?fun=2&idi=<?php echo "$ving"; ?>">Eliminar</a></td>
				</tr>
				<?php } ?>
			</table>
			<h1>Controle de opiniões</h1>
			<table id="ner">
				<tr>
					<td>Codigo</td>
					<td>Institutos</td>
					<td>Curso</td>
					<td>Email</td>
					<td>Oponião</td>
				</tr>
				<?php
					$query_opinio=mysql_query("select *from opinioes");
					while($result_opinio=mysql_fetch_array($query_opinio)){
						$cod=$result_opinio['id_opinioes'];
						$cod_insti=$result_opinio['id_institutos'];
						$q_i=mysql_query("select *from institutos where id_institutos='$cod_insti'");
						$r_i=mysql_fetch_array($q_i);
						$cod_i=$r_i['nome'];
						$cod_curso=$result_opinio['id_cursos'];
						$q_c=mysql_query("select *from cursos where id_cursos='$cod_curso'");
						$r_c=mysql_fetch_array($q_c);
						$cod_c=$r_c['nome'];
						$email=$result_opinio['email'];
						$opini=$result_opinio['opiniao'];
					
				?>
				<tr>
					<td><?php echo "$cod"; ?></td>
					<td><?php echo "$cod_i"; ?></td>
					<td><?php echo "$cod_c"; ?></td>
					<td><?php echo "$email"; ?></td>
					<td><?php echo "$opini"; ?></td>
					<td><a href="index.php?page=php/cadasInst_curso?fun=3&idi=<?php echo "$cod"; ?>">Eliminar</a></td>
				</tr>
				<?php } ?>
			</table>

				</body>
				</html>