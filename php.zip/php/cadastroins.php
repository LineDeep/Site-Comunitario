<?php include "conn.php"; ?>
<!doctype html>
<head>
	<style type="text/css">
	#ner td{
		padding: 10px;
	}
	</style>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cadrastro no Banco</title>
</head>

<body>
	<form method="POST" action="php/cadasInstituto.php?fun=1" name="form_inst" enctype="multipart/form-data">
	<table>
		<tr>
			<td><label>Nome:</label></td><td><input type="text" name="nome"></td>
		</tr>
		<tr>
			<td><label>Acronimo:</label></td><td><input type="text" name="acro"></td>
		</tr>

		<tr>
			<td><label>Localização:</label></td><td><textarea name="local"></textarea> </td>
		</tr>
		<tr>
			<td><label>Quantidade de Salas:</label></td><td><input type="text" name="qts"></td>
		</tr>
		<tr>
			<td><label>Criterio de Acesso:</label></td><td><textarea name="cts"></textarea></td>
		</tr>
		<tr>
			<td><label>Documento para Inscrição:</label></td><td><textarea name="dpi"></textarea></td>
		</tr>
		<tr>
			<td><label>Infomação:</label></td><td><textarea type="text" name="info"></textarea></td>

		</tr>
		<tr>
			<td><input type="submit" value="Cadastrar"></td>
		</tr>
		<tr><input type="file" name="img"/></tr>


	</table>
</form>
<?php
$select=mysql_query("select *from institutos");
?>
<table id="ner">
	<tr><a href="?page=centralphp"><input type="button" value="Voltar"></a></tr>
	<tr>
		<td>Codigo</td>
		<td>Acronimo</td>
		<td>Nome</td>
		<td>Localização</td>
		<td>Quantidades de Salas</td>
		<td>Criterio de Acesso</td>
		<td>Documento para Inscrição</td>
		<td>Informação</td>

	</tr>
	<?php
	while($rec_select=mysql_fetch_array($select)){
	$cod=$rec_select['id_institutos'];
	$acro=$rec_select['acronimo'];
	$nome=$rec_select['nome'];
	$local=$rec_select['localizacao'];
	$qts=$rec_select['qtd_salas'];
	$cts=$rec_select['criterio_acesso'];
	$dpi=$rec_select['doc_inscricao'];
	$info=$rec_select['info'];
	?>
	<tr>
		<td><?php echo "$cod"; ?></td>
		<td><?php echo "$acro"; ?></td>
		<td><?php echo "$nome"; ?></td>
		<td><?php echo "$local"; ?></td>
		<td><?php echo "$qts"; ?></td>
		<td><?php echo "$cts"; ?></td>
		<td><?php echo "$dpi"; ?></td>
		<td><?php echo "$info"; ?></td>
		<td><a href="php/cadasInstituto.php?fun=2&idi=<?php echo "$cod" ?>">Eliminar</a></td>
	</tr>
	<?php } ?>
	
</table>
</body>

</html>