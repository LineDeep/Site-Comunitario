<?php include "conn.php"; ?>



	<form method="POST" action="php/cadasDisciplina.php?fun=1" name="form_inst">
	<label>Nome:</label>
	<input type="text" name="nome_d">
	<label>Curso:</label>
	<select name="curso" style="">
	<option></option>
	<?php
	$select=mysql_query("select *from cursos");
	while($rec_select=mysql_fetch_array($select)){
	$nomes=$rec_select['nome'];
					
	?>
	<option> <?php echo "$nomes"; ?></option>
	<?php } ?>
	</select> 
	<button class="btn">Cadastrar</button>
	

	<table>
      <caption>
      Disciplinas Cadastradas
      </caption>
      <thead>
        <tr>
          <th>Codigo</th>
          <th>Nome</th>
          <th>Curso</th>
          <th>Operação</th>
        </tr>
      </thead>

      <?php
			$select=mysql_query("select *from disciplinas");
			while($rec_select=mysql_fetch_array($select)){
			$cod=$rec_select['id_disciplinas'];
			$nome=$rec_select['nome'];
			$curso=$rec_select['id_cursos'];
			$query=mysql_query("SELECT * FROM `cursos` WHERE id_cursos='$curso'");
 			$array_query=mysql_fetch_array($query);
			$gv_id=$array_query['nome'];
		?>

      <tbody>
        <tr>
        <td><?php echo "$cod" ?></td>
		<td><?php echo "$nome" ?></td>
		<td><?php echo "$gv_id" ?></td>
		<td><a href="cadasDisciplina.php?fun=2&id=<?php echo "$cod" ?>"><button class="btn"><i class="icon-trash"></i></button></a>
		</td> </tr>
        <?php } ?>
      </tbody>
    </table>

